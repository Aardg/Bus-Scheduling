The folder contains the results for the buswise algorithm that we developed.
points to note.
1. starting the allocation at 4pm enables all trips to be serviced.
2. starting the allocation at 9am leaves just 2 trips as unservicable
2. with on stretch being limited to 9 hours, both reduce the required number of buses to 28 (from 30 if the same constraint is applied to 00 hrs)

ps. : the graphs start from 9am and 4pm respectively and follow a circular style displaying the next day